#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc,char*argv[]){
    if(argc!=2){
        printf("Error");
        exit(-1);
    }
    int tick_number=atoi(argv[1]);
    if(tick_number<0){
        printf("Error");
        exit(0);
    }
    sleep(tick_number);
    exit(0);
}